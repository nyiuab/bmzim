
mzims <- function(y, formula, data, family = "nb", 
                  s_intercept = 10, s_dist = 1, s_zero = 1, s_disp = 1,
                  min.p = 0, sort = FALSE, verbose = TRUE)
{
  start.time <- Sys.time()
  
  call <- match.call()
  family <- family[1]
  y <- as.matrix(y)
  if (is.null(rownames(y))) rownames(y) <- paste("v", 1:nrow(y), sep = "")
  if (is.null(colnames(y))) colnames(y) <- paste("y", 1:ncol(y), sep = "")
  nonzero.p <- apply(y, 2, function(z) {length(z[z != 0])/length(z)} )
  if (sort){
    nonzero.p <- sort(nonzero.p, decreasing = TRUE)
    y <- y[, names(nonzero.p), drop = FALSE]
  }
  if (ncol(y) > 1 & min.p > 0){
    sub <- names(nonzero.p[nonzero.p > min.p])
    if (length(sub) == 0) stop("min.p is too large: no response") 
    else y <- y[, sub, drop = FALSE]
  }
  if (missing(data)) data <- NULL
  
  if (verbose) cat("Analyzing", ncol(y), "responses: \n")
  fm <- y.one ~ .
  fm[[3]] <- formula[[2]]
  fit <- vector(mode="list", length=NCOL(y))
  names(fit) <- colnames(y)
  for (j in 1:ncol(y)){
    y.one <- y[, j]
    data1 <- data.frame(cbind(y.one, data))
    tryCatch( {
      if (family %in% c("nb", "gaussian", "beta", "t"))
        fit[[j]] <- bm(formula=fm, data=data1, family=family, s_intercept=s_intercept, s_dist=s_dist, s_disp=s_disp, 
                       verbose=FALSE ) 
      if (family %in% c("zinb", "zig", "zib", "zit"))
        fit[[j]] <- bzim(formula=fm, data=data1, family=family, s_intercept=s_intercept, s_dist=s_dist, s_zero=s_zero, s_disp=s_disp,
                         verbose=FALSE ) 
      if (verbose) cat(j, "")
    }, error = function(e) {message("\n", "y", j, " error: ", conditionMessage(e), sep="")} )
  } 
  fit <- fit[!sapply(fit, is.null)]
  responses <- names(fit)
  variables <- lapply(fit[[1]]$coefficients, names)

  res <- list(fit=fit, responses=responses, variables=variables, call=call)
  
  class(res) <- c("mzims", family)
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units = "min"), 3)
  if (verbose) 
    cat("\n Computational time:", minutes, "minutes \n")
  
  res
}



  


