

predict.bm <- function(object, y, x, offset)
{
  if (object$algorithm != "optimizing") stop("only for 'optimizing' ")
  if (missing(y) & missing(x)){
    y <- object$y
    x <- object$x
    offset <- object$offset
  }
  if (class(x) != "list") stop("x should be a two-element list")
  if (length(x) != 2) stop("x should consist of two component")
  X <- as.matrix(x[[1]])
  Z <- as.matrix(x[[2]])
  if (missing(offset)){
    offset <- list()
    offset[[1]] <- offset[[2]] <- rep(0, NROW(X))
  } 
  
  family <- object$family 
  coefx <- object$coefficients[[1]]
  coefz <- object$coefficients[[2]]
  offsetx <- offset[[1]]
  offsetz <- offset[[2]]
  dist.eta <- mu <- offsetx + X%*%coefx
  disp.eta <- offsetz + Z%*%coefz
  
  if (family=="nb") {
    theta <- exp(disp.eta)
    mu <- exp(dist.eta)
  }
  if (family=="gaussian") sigma <- exp(disp.eta)
  if (family=="t") sigma <- exp(disp.eta)
  if (family=="beta") {
    theta <- exp(disp.eta)
    mu <- exp(dist.eta)/(1 + exp(dist.eta))
  }
  lp <- list(dist=dist.eta, disp=disp.eta)
  fitted.values <- mu
  
  out <- list(lp = lp, fitted.values = fitted.values)
  
  deviance <- mae <- measures <- NULL  
  if (!missing(y)){
    if (family=="nb") den <- dnbinom(y, size=theta, mu=mu)
    if (family=="gaussian") den <- dnorm(y, mu, sigma)
    if (family=="t") den <- dt((y-mu)/sigma, object$df)
    if (family=="beta") den <- dbeta(y, mu*theta, (1-mu)*theta)
    deviance <- round(-2*sum(log(den)), digits=3)
    mae <- round(mean(abs(y - mu), na.rm = TRUE), digits=3)
    measures <- list(deviance = deviance, mae = mae)
    out$measures <- unlist(measures)
  }
  
  out
}


predict.bzim <- function(object, y, x, offset)
{
  if (object$algorithm != "optimizing") stop("only for 'optimizing' ")
  if (missing(y) & missing(x)){
    y <- object$y
    x <- object$x
    offset <- object$offset
  }
  if (class(x) != "list") stop("x should be a three-element list")
  if (length(x) != 3) stop("x should consist of three component")
  X <- as.matrix(x[[1]])
  Z <- as.matrix(x[[2]])
  W <- as.matrix(x[[3]])
  if (missing(offset)){
    offset <- list()
    offset[[1]] <- offset[[2]] <- offset[[3]] <- rep(0, NROW(X))
  } 
  
  family <- object$family 
  coefx <- object$coefficients[[1]]
  coefz <- object$coefficients[[2]]
  coefw <- object$coefficients[[3]]
  offsetx <- offset[[1]]
  offsetz <- offset[[2]]
  offsetw <- offset[[3]]
  dist.eta <- mu <- offsetx + X%*%coefx
  zero.eta <- offsetz + Z%*%coefz
  disp.eta <- offsetw + W%*%coefw
  
  if (family=="zinb") {
    theta <- exp(disp.eta)
    mu <- exp(dist.eta)
  }
  if (family == "zig") sigma <- exp(disp.eta)
  if (family == "zit") sigma <- exp(disp.eta)
  if (family=="zib") {
    theta <- exp(disp.eta)
    mu <- exp(dist.eta)/(1 + exp(dist.eta))
  }
  zero.prob <- exp(zero.eta)/(1 + exp(zero.eta))
  lp <- list(dist=dist.eta, zero=zero.eta, disp=disp.eta)
  fitted.values <- (1 - zero.prob) * mu
  
  out <- list(lp = lp, fitted.values = fitted.values, zero.prob = zero.prob)
  
  deviance <- mae <- measures <- NULL  
  if (!missing(y)){
    if (family=="zinb") den <- dnbinom(y, size=theta, mu=mu)
    if (family=="zig") den <- dnorm(y, mu, sigma)
    if (family=="zit") den <- dt((y-mu)/sigma, object$df)
    if (family=="zib") den <- dbeta(y, mu*theta, (1-mu)*theta)
    loglik0 <- log(zero.prob + (1 - zero.prob) * den)
    loglik1 <- log((1 - zero.prob) * den)
    loglik <- sum(loglik0[y == 0]) + sum(loglik1[y != 0])
    deviance <- round(-2*loglik, digits=3)
    mae <- round(mean(abs(y - fitted.values), na.rm = TRUE), digits=3)
    measures <- list(deviance = deviance, mae = mae)
    out$measures <- unlist(measures)
  }
  
  out
}

