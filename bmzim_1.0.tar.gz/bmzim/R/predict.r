

predict.bm <- function (object, new.x, new.y) 
{
  if (!missing(new.x) & !missing(new.y)){
    if (NROW(new.x)!=NROW(new.y))
      stop("'new.x' and 'new.y' should be the same length.", call. = FALSE)
  }
  
  if (missing(new.y)) y <- object$y
  else y <- new.y
  
  if (missing(new.x))
  {
    dist.eta <- object$linear.predictors$dist
    disp.eta <- object$linear.predictors$disp
  }
  else
  {  
    mf <- model.frame(delete.response(object$terms$full), 
                      new.x, na.action = na.pass, xlev = object$levels)
    x <- model.matrix(delete.response(object$terms$dist), 
                      mf, contrasts = object$contrasts$dist)
    z <- model.matrix(delete.response(object$terms$disp), 
                      mf, contrasts = object$contrasts$disp)
    offsetx <- model_offset_2(mf, terms = object$terms$dist, offset = FALSE)
    offsetz <- model_offset_2(mf, terms = object$terms$disp, offset = FALSE)
    if (is.null(offsetx)) offsetx <- rep.int(0, NROW(x))
    if (is.null(offsetz)) offsetz <- rep.int(0, NROW(z))
    dist.eta <- as.numeric(offsetx + x %*% object$coefficients$dist)
    disp.eta <- as.numeric(offsetz + z %*% object$coefficients$disp)
    names(dist.eta) <- names(disp.eta) <- 1:NROW(x)
  }
  lp <- list(dist=dist.eta, disp=disp.eta)
  res <- measure.bm(dist.eta=dist.eta, disp.eta=disp.eta, y=y, family=object$family, 
                    dispersion=exp(disp.eta), aux=object$df)
  measures <- list(loglik=res$loglik, deviance=res$deviance, mae=res$mae)
  
  out <- list(lp=lp, fitted.values=res$fitted.values, measures=unlist(measures))
  
  out  
}


predict.bzim <- function (object, new.x, new.y) 
{
  if (!missing(new.x) & !missing(new.y)){
    if (NROW(new.x)!=NROW(new.y))
      stop("'new.x' and 'new.y' should be the same length.", call. = FALSE)
  }
  
  if (missing(new.y)) y <- object$y
  else y <- new.y
  
  if (missing(new.x))
  {
    dist.eta <- object$linear.predictors$dist
    zero.eta <- object$linear.predictors$zero
    disp.eta <- object$linear.predictors$disp
  }
  else
  {  
    mf <- model.frame(delete.response(object$terms$full), 
                      new.x, na.action = na.pass, xlev = object$levels)
    x <- model.matrix(delete.response(object$terms$dist), 
                      mf, contrasts = object$contrasts$dist)
    z <- model.matrix(delete.response(object$terms$zero), 
                      mf, contrasts = object$contrasts$zero)
    w <- model.matrix(delete.response(object$terms$disp), 
                      mf, contrasts = object$contrasts$disp)
    offsetx <- model_offset_2(mf, terms = object$terms$dist, offset = FALSE)
    offsetz <- model_offset_2(mf, terms = object$terms$zero, offset = FALSE)
    offsetw <- model_offset_2(mf, terms = object$terms$disp, offset = FALSE)
    if (is.null(offsetx)) offsetx <- rep.int(0, NROW(x))
    if (is.null(offsetz)) offsetz <- rep.int(0, NROW(z))
    if (is.null(offsetw)) offsetw <- rep.int(0, NROW(w))
    dist.eta <- as.numeric(offsetx + x %*% object$coefficients$dist)
    zero.eta <- as.numeric(offsetz + z %*% object$coefficients$zero)
    disp.eta <- as.numeric(offsetw + w %*% object$coefficients$disp)
    names(dist.eta) <- names(zero.eta) <- names(disp.eta) <- 1:NROW(x)
  }
  lp <- list(dist=dist.eta, zero=zero.eta, disp=disp.eta)
  res <- measure.bzim(dist.eta=dist.eta, zero.eta=zero.eta, disp.eta=disp.eta, y=y, family=object$family, 
                      dispersion=exp(disp.eta), aux=object$df)
  measures <- list(loglik=res$loglik, deviance=res$deviance, mae=res$mae)
  
  out <- list(lp=lp, fitted.values=res$fitted.values, measures=unlist(measures))
  
  out  
}


