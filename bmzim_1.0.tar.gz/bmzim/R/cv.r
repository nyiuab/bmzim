
cv <- function(object, nfolds = 10, foldid = NULL, ncv = 1, verbose = TRUE)
{  
  y.obj <- object$y
  n <- NROW(y.obj)
  x.obj <- object$x[[1]]
  z.obj <- object$x[[2]]
  if (any(class(object)=="bzim")) w.obj <- object$x[[3]]
  offsetx <- object$offset[[1]]
  offsetz <- object$offset[[2]]
  offsetw <- NULL
  if (any(class(object)=="bzim")) offsetw <- object$offset[[3]]
  if (is.null(offsetx)) offsetx <- rep.int(0, n)
  if (is.null(offsetz)) offsetz <- rep.int(0, n)
  if (is.null(offsetw)) offsetw <- rep.int(0, n)
  
  measures0 <- fitted0 <- foldid0 <- NULL
  fold <- foldid
  if (!is.null(foldid)) {
    fold <- as.matrix(foldid)
    nfolds <- max(foldid)
    ncv <- ncol(fold)
  }
  if (nfolds > n) nfolds <- n
  if (nfolds == n) ncv <- 1
  j <- 0
  
  if (verbose) cat("Fitting", "ncv*nfolds =", ncv * nfolds, "models: \n")
  for (k in 1:ncv) {
    
    fitted <- rep(NA, n)
    deviance <- NULL
    
    if (!is.null(fold)) foldid <- fold[, k]
    else foldid <- sample(rep(seq(nfolds), length = n)) 
    
    for (i in 1:nfolds) {
      subset1 <- rep(TRUE, n)
      omit <- which(foldid == i)
      subset1[omit] <- FALSE
      fit <- update(object, subset=subset1, hessian=FALSE, verbose=FALSE)
      if (any(class(object)=="bm")){
        dist.eta <- offsetx[omit] + x.obj[omit, , drop = FALSE] %*% fit$coefficients$dist
        disp.eta <- offsetz[omit] + z.obj[omit, , drop = FALSE] %*% fit$coefficients$disp
        dd <- measure.bm(dist.eta=dist.eta, disp.eta=disp.eta, y=y.obj[omit], family=object$family, 
                         dispersion=exp(disp.eta), aux=fit$df)
      }
      if (any(class(object)=="bzim")){
        dist.eta <- offsetx[omit] + x.obj[omit, , drop = FALSE] %*% fit$coefficients$dist
        zero.eta <- offsetz[omit] + z.obj[omit, , drop = FALSE] %*% fit$coefficients$zero
        disp.eta <- offsetw[omit] + w.obj[omit, , drop = FALSE] %*% fit$coefficients$disp
        dd <- measure.bzim(dist.eta=dist.eta, zero.eta=zero.eta, disp.eta=disp.eta, y=y.obj[omit], 
                           family=object$family, dispersion=exp(disp.eta), aux=fit$df) 
      }
      fitted[omit] <- dd$fitted.values
      deviance <- c(deviance, dd[["deviance"]])
      
      if (verbose) {
        j <- j + 1
        cat(j, "")
      }
    }
    
    deviance <- round(sum(deviance), digits=3)
    mae <- round(mean(abs(y.obj - fitted), na.rm = TRUE), digits=3)
    measures <- list(deviance = deviance, mae = mae)
    measures <- unlist(measures)
    
    measures0 <- rbind(measures0, measures)
    fitted0 <- cbind(fitted0, fitted)
    foldid0 <- cbind(foldid0, foldid)
    
  }
  
  out <- list()
  if (nrow(measures0) == 1) out$measures <- colMeans(measures0)
  else {
    out$measures <- rbind(colMeans(measures0), apply(measures0, 2, sd))
    rownames(out$measures) <- c("mean", "sd")
  }
  out$fitted.values <- rowMeans(fitted0, na.rm = TRUE)
  out$foldid <- foldid0
  
  out
}
