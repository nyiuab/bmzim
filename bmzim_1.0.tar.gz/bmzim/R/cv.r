

cv <- function(object, nfolds = 10, foldid = NULL, ncv = 1, verbose = TRUE)
{  
  if (object$algorithm != "optimizing") stop("only for 'optimizing' ")
  x.obj <- object$x
  y.obj <- object$y
  n <- NROW(y.obj)
  offset <- object$offset
  
  out <- list()
  out$y.obs <- y.obj
  
  measures0 <- NULL
  fitted0 <- NULL
  fold <- foldid
  foldid0 <- NULL
  if (!is.null(foldid)) {
    fold <- as.matrix(foldid)
    nfolds <- max(foldid)
    ncv <- ncol(fold)
  }
  j <- 0
  
  if (nfolds > n) nfolds <- n
  if (nfolds == n) ncv <- 1
  
  for (k in 1:ncv) {
    
    fitted <- rep(NA, n)
    deviance <- NULL
    
    if (!is.null(fold)) foldid <- fold[, k]
    else foldid <- sample(rep(seq(nfolds), length = n)) 
    
    for (i in 1:nfolds) {
      subset1 <- rep(TRUE, n)
      omit <- which(foldid == i)
      subset1[omit] <- FALSE
      fit <- update(object, subset=subset1, hessian=FALSE, verbose=FALSE)
      
      x1 <- off1 <- list()
      x1[[1]] <- x.obj[[1]][omit, , drop = FALSE]
      x1[[2]] <- x.obj[[2]][omit, , drop = FALSE]
      off1[[1]] <- offset[[1]][omit]
      off1[[2]] <- offset[[2]][omit]
      if (class(object) == "bzim"){
        x1[[3]] <- x.obj[[3]][omit, , drop = FALSE]
        off1[[3]] <- offset[[3]][omit]
      }
      y1 <- y[omit]
      
      dd <- predict(fit, y=y1, x=x1, offset=off1)
      fitted[omit] <- dd$fitted.values
      deviance <- c(deviance, dd$measures["deviance"])
      
      if (verbose) {
        J <- nfolds * ncv
        j <- j + 1
        pre <- rep("\b", J)
        cat(pre, "\n", j, "/", J, "\n", sep = "")
        flush.console()
      }
    }
    
    deviance <- sum(deviance)
    mae <- mean(abs(y.obj - fitted), na.rm = TRUE)
    measures <- list(deviance = deviance, mae = mae)
    measures <- unlist(measures)
    
    measures0 <- rbind(measures0, measures)
    fitted0 <- cbind(fitted0, fitted)
    foldid0 <- cbind(foldid0, foldid)
    
  }
  
  if (!any(is.na(fitted0))) out$fitted.values <- rowMeans(fitted0)
  if (nrow(measures0) == 1) out$measures <- colMeans(measures0)
  else {
    out$measures <- rbind(colMeans(measures0), apply(measures0, 2, sd))
    rownames(out$measures) <- c("mean", "sd")
  }
  out$foldid <- foldid0
  
  out
}
