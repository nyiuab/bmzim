
measure <- function(object, new.x, new.y)
{
  if (!missing(new.x) & !missing(new.y)){
    if (NROW(new.x)!=NROW(new.y))
      stop("'new.x' and 'new.y' should be the same length.", call. = FALSE)
  }
  if (missing(new.y)) y <- object$y
  else y <- new.y
  
  pred <- predict(object=object, new.x=new.x)
  
  if (class(object)=="bm")
    out <- measure.bm(y=y, dist.eta=pred$dist.eta, disp.eta=pred$disp.eta, 
                      family=object$family, aux=object$df)
  if (class(object)=="bzim")
    out <- measure.bzim(y=y, dist.eta=pred$dist.eta, zero.eta=pred$zero.eta, disp.eta=pred$disp.eta, 
                      family=object$family, aux=object$df)
  out
}


measure.bm <- function(y, dist.eta, disp.eta, family, aux=NULL)
{
  dispersion <- exp(disp.eta)
  if (family=="nb") {
    mu <- exp(dist.eta)
    den <- dnbinom(y, size=dispersion, mu=mu)
  }
  if (family=="gaussian") {
    mu <- dist.eta
    den <- dnorm(y, mu, dispersion)
  }
  if (family=="t") {
    mu <- dist.eta
    den <- dt((y-mu)/dispersion, aux)
  } 
  if (family=="beta") {
    mu <- exp(dist.eta)/(1 + exp(dist.eta))
    den <- dbeta(y, mu*dispersion, (1-mu)*dispersion)
  }
  loglik <- round(sum(log(den), na.rm=TRUE), digits=3)
  deviance <- -2 * loglik
  mae <- round(mean(abs(y - mu), na.rm=TRUE), digits=3)
  out <- list(deviance=deviance, mae=mae)
  unlist(out)
}


measure.bzim <- function(y, dist.eta, zero.eta, disp.eta, family, aux=NULL)
{
  dispersion <- exp(disp.eta)
  if (family=="zinb") {
    mu <- exp(dist.eta)
    den <- dnbinom(y, size=dispersion, mu=mu)
  }
  if (family == "zig") {
    mu <- dist.eta
    den <- dnorm(y, mu, dispersion)
  }
  if (family == "zit") {
    mu <- dist.eta
    den <- dt((y-mu)/dispersion, aux)
  }
  if (family=="zib") {
    mu <- exp(dist.eta)/(1 + exp(dist.eta))
    den <- dbeta(y, mu*dispersion, (1-mu)*dispersion)
  }
  zero.prob <- exp(zero.eta)/(1 + exp(zero.eta))
  zero.prob <- as.vector(zero.prob)
#  zp <- 1/(1 + exp(-zero.eta) * den)
#  zp <- ifelse(y != 0, 0, zp)
  loglik0 <- log(zero.prob + (1 - zero.prob) * den)
  loglik1 <- log((1 - zero.prob) * den)
  loglik <- round(sum(loglik0[y == 0]) + sum(loglik1[y != 0]), digits=3)
  deviance <- -2 * loglik
  fitted.values <- (1 - zero.prob) * mu
  mae <- round(mean(abs(y - fitted.values), na.rm=TRUE), digits=3)
  out <- list(deviance=deviance, mae=mae)
  unlist(out)
}
