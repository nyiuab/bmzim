

bzim <- function (formula, data, subset, family = c("zinb", "zig", "zit", "zib"), 
                  hessian = TRUE, s_intercept = 10, s_dist = 1, s_zero = 1, s_disp = 1,
                  verbose = FALSE) 
{
  start.time <- Sys.time()
  
  call <- match.call()
  family <- family[1]
  if (!family %in% c("zinb", "zig", "zit", "zib")) stop("wrong model")
  if (s_intercept==Inf) s_intercept <- 1e+05
  if (s_dist==Inf) s_dist <- 1e+05
  if (s_zero==Inf) s_zero <- 1e+05
  if (s_disp==Inf) s_disp <- 1e+05
  s_intercept <- max(s_intercept, s_dist, s_zero, s_disp)
  
  if (missing(data)) data <- environment(formula)
  mf <- match.call(expand.dots = FALSE)
  m <- match(c("formula", "data", "subset", "na.action", "weights", "offset"), names(mf), 0)
  mf <- mf[c(1, m)]
  mf$drop.unused.levels <- TRUE
  
  ff <- formula
  formula[[3]][1] <- call("+")
  formula[[3]][[2]][1] <- call("+")  
  mf$formula <- formula
  ffc <- . ~ .
  ffz <- ~.
  ffw <- ~.
  ffc[[2]] <- ff[[2]]
  ffc[[3]] <- ff[[3]][[2]][[2]]
  ffz[[3]] <- ff[[3]][[2]][[3]]
  ffz[[2]] <- NULL
  ffw[[3]] <- ff[[3]][[3]]
  ffw[[2]] <- NULL
  
  if (inherits(try(terms(ffz), silent = TRUE), "try-error")) {
    ffz <- eval(parse(text = sprintf(paste("%s -", deparse(ffc[[2]])), deparse(ffz))))
  }
  if (inherits(try(terms(ffd), silent = TRUE), "try-error")) {
    ffw <- eval(parse(text = sprintf(paste("%s -", deparse(ffc[[2]])), deparse(ffw))))
  }
  
  mf[[1]] <- as.name("model.frame")
  mf <- eval(mf, parent.frame())
  mt <- attr(mf, "terms")
  mtX <- terms(ffc, data = data)
  X <- model.matrix(mtX, mf)
  mtZ <- terms(ffz, data = data)
  mtZ <- terms(update(mtZ, ~.), data = data)
  Z <- model.matrix(mtZ, mf)
  mtW <- terms(ffw, data = data)
  mtW <- terms(update(mtW, ~.), data = data)
  W <- model.matrix(mtW, mf)
  Y <- model.response(mf, "numeric")
  offsetx <- model_offset_2(mf, terms = mtX, offset = FALSE)
  if (is.null(offsetx)) offsetx <- rep(0, length(Y))
  offsetz <- model_offset_2(mf, terms = mtZ, offset = FALSE)
  if (is.null(offsetz)) offsetz <- rep(0, length(Y))
  offsetw <- model_offset_2(mf, terms = mtW, offset = FALSE)
  if (is.null(offsetw)) offsetw <- rep(0, length(Y))
  
  if (all(Y != 0)) stop("invalid dependent variable, all outcome values are not zero")
  nobs <- length(Y)
  kx <- NCOL(X) 
  kz <- NCOL(Z)
  kw <- NCOL(W)
  if (family == "zib") Y <- ifelse(Y>=1, 1-0.5/nobs, Y)
  
  Dat <- list(n=nobs, kx=kx, kz=kz, kw=kw, x=X, z=Z, w=W, y=Y, 
              offsetx=offsetx, offsetz=offsetz, offsetw=offsetw, 
              s0=s_intercept, s1=s_dist, s2=s_zero, s3=s_disp)
  if (family == "zinb") sm <- stanmodels$zinb_cauchy
  if (family == "zig") sm <- stanmodels$zig_cauchy 
  if (family == "zit") sm <- stanmodels$zit_cauchy
  if (family == "zib") sm <- stanmodels$zig_cauchy
  
    fit <- suppressMessages(suppressWarnings(optimizing(sm, data=Dat, init=0, hessian=hessian)))
    
    res <- NULL
    if (!is.null(fit)){
      res <- list()
      res$stan <- fit
      coefx <- fit$par[1:kx]
      names(coefx) <- colnames(X)
      coefz <- fit$par[(kx+1):(kx+kz)]
      names(coefz) <- colnames(Z)
      coefw <- fit$par[(kx+kz+1):(kx+kz+kw)]
      names(coefw) <- colnames(W)
      res$coefficients <- list(dist=coefx, zero=coefz, disp=coefw)
      
      dist.eta <- mu <- offsetx + X%*%coefx
      zero.eta <- offsetz + Z%*%coefz
      disp.eta <- offsetw + W%*%coefw
    
      if (family=="zinb") {
        res$theta <- exp(disp.eta)
        mu <- exp(dist.eta)
        den <- dnbinom(Y, size=res$theta, mu=mu)
      }
      if (family == "zig") {
        res$sigma <- exp(disp.eta)
        den <- dnorm(Y, mu, res$sigma)
      }
      if (family == "zit") {
        res$sigma <- exp(disp.eta)
        res$df <- 1/fit$par[(kx+kz+kw+1)]
        names(res$df) <- "df"
        den <- dt((Y-mu)/res$sigma, res$df)  
      }
      if (family=="zib") {
        res$theta <- exp(disp.eta)
        mu <- exp(dist.eta)/(1 + exp(dist.eta))
        den <- dbeta(Y, mu*res$theta, (1-mu)*res$theta)
      }
    
      zero.prob <- exp(zero.eta)/(1 + exp(zero.eta))
      zp <- 1/(1 + exp(-zero.eta) * den )
      zp <- ifelse(Y != 0, 0, zp)
      loglik0 <- log(zero.prob + (1 - zero.prob) * den)
      loglik1 <- log((1 - zero.prob) * den)
      res$loglik <- sum(loglik0[Y == 0]) + sum(loglik1[Y != 0])
      res$zero.prob <- as.vector(zero.prob)
      fit$zero.indicator <- zp
      res$fitted.values <- (1 - zero.prob) * mu
      res$linear.predictors <- list(dist=dist.eta, zero=zero.eta, disp=disp.eta)
  
      res$formula <- formula
      res$formula.dist <- ffc
      res$formula.zero <- ffz
      res$formula.disp <- ffw
      res$y <- Y
      res$x <- list(dist=X, zero=Z, disp=W)
      res$offset <- list(dist=offsetx, zero=offsetz, disp=offsetw)
      res$family <- family
      res$call <- call
      class(res) <- "bzim"
    }
  
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units = "min"), 3)
  if (verbose) 
    cat("\n Computational time:", minutes, "minutes \n")
  
  return(res)
}



