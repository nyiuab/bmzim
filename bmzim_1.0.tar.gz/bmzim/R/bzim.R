
bzim <- function (formula, data, subset, family=c("zinb", "zig", "zit", "zib"), 
                  s_intercept=10, s_dist=1, s_zero=1, s_disp=1, hessian=TRUE, 
                  verbose=TRUE) 
{
  start.time <- Sys.time()
  
  call <- match.call()
  family <- family[1]
  if (!family %in% c("zinb", "zig", "zit", "zib")) stop("wrong model")
  if (s_intercept==Inf) s_intercept <- 1e+05
  s_dist <- ifelse(s_dist==Inf, 1e+05, s_dist)
  s_zero <- ifelse(s_zero==Inf, 1e+05, s_zero)
  s_disp <- ifelse(s_disp==Inf, 1e+05, s_disp)
  s_intercept <- max(s_intercept, s_dist, s_zero, s_disp)
  
  if (missing(data)) data <- environment(formula)
  mf <- match.call(expand.dots = FALSE)
  m <- match(c("formula", "data", "subset", "na.action", "weights", "offset"), names(mf), 0)
  mf <- mf[c(1, m)]
  mf$drop.unused.levels <- TRUE
  
  ff <- formula
  formula[[3]][1] <- call("+")
  formula[[3]][[2]][1] <- call("+")  
  mf$formula <- formula
  ffc <- . ~ .
  ffz <- ~.
  ffw <- ~.
  ffc[[2]] <- ff[[2]]
  ffc[[3]] <- ff[[3]][[2]][[2]]
  ffz[[3]] <- ff[[3]][[2]][[3]]
  ffz[[2]] <- NULL
  ffw[[3]] <- ff[[3]][[3]]
  ffw[[2]] <- NULL
  
  if (inherits(try(terms(ffz), silent = TRUE), "try-error")) {
    ffz <- eval(parse(text = sprintf(paste("%s -", deparse(ffc[[2]])), deparse(ffz))))
  }
  if (inherits(try(terms(ffd), silent = TRUE), "try-error")) {
    ffw <- eval(parse(text = sprintf(paste("%s -", deparse(ffc[[2]])), deparse(ffw))))
  }
  
  mf[[1]] <- as.name("model.frame")
  mf <- eval(mf, parent.frame())
  mt <- attr(mf, "terms")
  mtX <- terms(ffc, data = data)
  X <- model.matrix(mtX, mf)
  mtZ <- terms(ffz, data = data)
  mtZ <- terms(update(mtZ, ~.), data = data)
  Z <- model.matrix(mtZ, mf)
  mtW <- terms(ffw, data = data)
  mtW <- terms(update(mtW, ~.), data = data)
  W <- model.matrix(mtW, mf)
  Y <- model.response(mf, "numeric")
  offsetx <- model_offset_2(mf, terms = mtX, offset = FALSE)
  if (is.null(offsetx)) offsetx <- rep(0, NROW(X))
  offsetz <- model_offset_2(mf, terms = mtZ, offset = FALSE)
  if (is.null(offsetz)) offsetz <- rep(0, NROW(X))
  offsetw <- model_offset_2(mf, terms = mtW, offset = FALSE)
  if (is.null(offsetw)) offsetw <- rep(0, NROW(X))
  if (all(Y != 0)) stop("invalid dependent variable: all outcome values are nonzero")
  if (family == "zib") Y <- ifelse(Y>=1, 1-0.5/NROW(X), Y)
  n <- NROW(X)
  
  fit <- bzim.fit(x=X, z=Z, w=W, y=Y, offsetx=offsetx, offsetz=offsetz, offsetw=offsetw,
                family=family, s0=s_intercept, s1=s_dist, s2=s_zero, s3=s_disp, hessian=hessian, code=code) 
  
  fit <- c(fit, list(family=family, formula=ff, formula.dist=ffc, formula.zero=ffz, formula.disp=ffw,
                     y=Y, x=list(dist=X, zero=Z, disp=W), 
                     offset=list(dist=if(identical(offsetx, rep(0, n))) NULL else offsetx, 
                                 zero=if(identical(offsetz, rep(0, n))) NULL else offsetz,
                                 disp=if(identical(offsetw, rep(0, n))) NULL else offsetw),
                     terms=list(dist=mtX, zero=mtZ, disp=mtW, full=mt), levels=.getXlevels(mt, mf), 
                     contrasts=list(dist=attr(X, "contrasts"), zero=attr(Z, "contrasts"), disp=attr(W, "contrasts"))) )
  
  fit$call <- call 
  class(fit) <- "bzim"
  
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units = "min"), 3)
  if (verbose) 
    cat("Computational time:", minutes, "minutes \n")
  
  return(fit)
}

bzim.fit <- function(x, z, w, y, offsetx, offsetz, offsetw, family,  
                     s0, s1, s2, s3, hessian, code) 
{
  nobs <- NROW(x)
  kx <- NCOL(x) 
  kz <- NCOL(z)
  kw <- NCOL(w)
  if (colnames(x)[1]=="(Intercept)" & kx>1) s1 <- c(s0, s1)
  if (colnames(x)[1]=="(Intercept)" & kx==1) s1 <- s0
  if (length(s1)<kx) s1 <- c(s1, rep(s1[length(s1)], kx-length(s1)))
  if (colnames(z)[1]=="(Intercept)" & kz>1) s2 <- c(s0, s2)
  if (colnames(z)[1]=="(Intercept)" & kz==1) s2 <- s0
  if (length(s2)<kz) s2 <- c(s2, rep(s2[length(s2)], kz-length(s2)))
  if (colnames(w)[1]=="(Intercept)" & kw>1) s3 <- c(s0, s3)
  if (colnames(w)[1]=="(Intercept)" & kw==1) s3 <- s0
  if (length(s3)<kw) s3 <- c(s3, rep(s3[length(s3)], kw-length(s3)))
  names(s1) <- colnames(x)
  names(s2) <- colnames(z)
  names(s3) <- colnames(w)
  
  s1 <- s1 / autoscale(x, min.x.sd=1e-04)
  s2 <- s2 / autoscale(z, min.x.sd=1e-04)
  s3 <- s3 / autoscale(w, min.x.sd=1e-04)
  if (family %in% c("zig","zit")) {
    s1 <- s1 * sd(y)
    s3 <- s3 * sd(y)
  }
  
  if (family == "zinb") sm <- stanmodels$zinb_stan
  if (family == "zig") sm <- stanmodels$zig_stan 
  if (family == "zit") sm <- stanmodels$zit_stan
  if (family == "zib") sm <- stanmodels$zig_stan
  data <- list(n=nobs, kx=kx, kz=kz, kw=kw, x=x, z=z, w=w, y=y, 
              offsetx=offsetx, offsetz=offsetz, offsetw=offsetw, 
              s=c(s1,s2,s3))
  res <- list()
  res$stanmodel <- sm 
  res$standata <- data
  
  fit <- suppressMessages(suppressWarnings(optimizing(sm, data=data, init=0, hessian=hessian)))
  if (!is.null(fit)){
    coefx <- fit$par[1:kx]
    names(coefx) <- colnames(x)
    coefz <- fit$par[(kx+1):(kx+kz)]
    names(coefz) <- colnames(z)
    coefw <- fit$par[(kx+kz+1):(kx+kz+kw)]
    names(coefw) <- colnames(w)
    res$coefficients <- list(dist=coefx, zero=coefz, disp=coefw)
    res$hessian <- fit$hessian
      
    dist.eta <- as.numeric(offsetx + x%*%coefx)
    zero.eta <- as.numeric(offsetz + z%*%coefz)
    disp.eta <- as.numeric(offsetw + w%*%coefw)
    names(dist.eta) <- names(zero.eta) <- names(disp.eta) <- 1:NROW(x)
    res$disperion <- exp(disp.eta)
    df <- NULL
    if (family=="zit") {
      df <- 1/fit$par[(kx+kz+kw+1)]
      res$df <- df
      names(res$df) <- "df"
    } 
    res$linear.predictors <- list(dist=dist.eta, zero=zero.eta, disp=disp.eta)
    res$prior.scale <- list(dist=s1, zero=s2, disp=s3)
  }
  
  res
}

#********************************************************************


