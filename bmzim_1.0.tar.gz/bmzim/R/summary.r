

summary.bm <- function(object) 
{
  res <- coefs <- object$coefficients
  kx <- length(coefs[[1]])
  kz <- length(coefs[[2]])
  k1 <- c(1:kx) 
  k2 <- c((kx+1):(kx+kz))
  par <- c(coefs[[1]], coefs[[2]])
  par <- round(par, digits = 3)
  hess <- object$stan$hessian
  if (!missing(hess)){
    if (NCOL(hess) > 1) vc <- -solve(hess + diag(rep(1e-03, NCOL(hess))))
    else vc <- -1/(hess + 1e-03)
    diag.vc <- diag(vc)[1:length(par)]
    s.err <- sqrt(diag.vc)
    tvalue <- par/s.err
    pvalue <- 2 * pnorm(-abs(tvalue))
    s.err <- round(s.err, digits = 3)
    pvalue <- signif(pvalue, 2)
    res[[1]] <- cbind(par[k1], s.err[k1], pvalue[k1])
    res[[2]] <- cbind(par[k2], s.err[k2], pvalue[k2])
    colnames(res[[1]]) <- colnames(res[[2]]) <- c("Estimate", "Std. Error", "pvalue")  
  }
  
  res
}


summary.bzim <- function(object) 
{
  res <- coefs <- object$coefficients
  kx <- length(coefs[[1]])
  kz <- length(coefs[[2]])
  kw <- length(coefs[[3]])
  k1 <- c(1:kx) 
  k2 <- c((kx+1):(kx+kz))
  k3 <- c((kx+kz+1):(kx+kz+kw))
  par <- c(coefs[[1]], coefs[[2]], coefs[[3]])
  par <- round(par, digits = 3)
  hess <- object$stan$hessian
  if (!missing(hess)){
    if (NCOL(hess) > 1) vc <- -solve(hess + diag(rep(1e-03, NCOL(hess))))
    else vc <- -1/(hess + 1e-03)
    diag.vc <- diag(vc)[1:length(par)]
    s.err <- sqrt(diag.vc)
    tvalue <- par/s.err
    pvalue <- 2 * pnorm(-abs(tvalue))
    s.err <- round(s.err, digits = 3)
    pvalue <- signif(pvalue, 2)
    res[[1]] <- cbind(par[k1], s.err[k1], pvalue[k1])
    res[[2]] <- cbind(par[k2], s.err[k2], pvalue[k2])
    res[[3]] <- cbind(par[k3], s.err[k3], pvalue[k3])
    colnames(res[[1]]) <- colnames(res[[2]]) <- colnames(res[[3]]) <- c("Estimate", "Std. Error", "pvalue")  
  }
  
  res
}


summary.mzims <- function(object) 
{
  fit <- object[[1]]
  out <- lapply(fit, summary)
  
  res <- vector(mode="list", length = length(out[[1]]))
  names(res) <- names(out[[1]])
  for (k in 1:length(res)){
    responses <- NULL
    for (j in 1:length(out)){
      res[[k]] <- rbind(res[[k]], out[[j]][[k]])
      responses <- c(responses, rep(names(out)[j], nrow(out[[j]][[k]])))
    }
    variables <- rownames(res[[k]])
    res[[k]] <- data.frame(responses, variables, res[[k]])
    rownames(res[[k]]) <- paste(res[[k]][,1], "--", res[[k]][,2], sep="")
  }
  
  res
}
  

#***********************************************************************





