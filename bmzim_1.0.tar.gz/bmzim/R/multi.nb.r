

multi.nb <- function (formula, data, subset,
                algorithm = c("optimizing", "sampling", "vb"), hessian = TRUE, 
                s = 1, iter = 2000, chains = 3, verbose = FALSE, ...) 
{
  start.time <- Sys.time()
  
  call <- match.call()
  algorithm <- algorithm[1]
  if (s==Inf) s <- 1e+05
  
  if (missing(data)) data <- environment(formula)
  mf <- match.call(expand.dots = FALSE)
  m <- match(c("formula", "data", "subset", "na.action", "weights", "offset"), names(mf), 0)
  mf <- mf[c(1, m)]
  mf$drop.unused.levels <- TRUE
  mf$formula <- formula
  mf[[1]] <- as.name("model.frame")
  mf <- eval(mf, parent.frame())
  mt <- attr(mf, "terms")
  mtX <- terms(formula, data = data)
  X <- model.matrix(mtX, mf)
  Y <- model.response(mf, "numeric")
  T <- rowSums(Y)
  
  if (colnames(X)[1]=="(Intercept)") X <- X[, -1, drop = FALSE]
  nobs <- NROW(X)
  k <- NCOL(Y)
  J <- NCOL(X)
  
  Dat <- list(n=nobs, k=k, J=J, x=t(X), y=t(Y), T=T, s=s)
  
  sm <- stanmodels$multi_nb
  
  if (algorithm == "optimizing") {
    fit <- suppressMessages(suppressWarnings(optimizing(sm, data=Dat, init=0, hessian=hessian, iter=iter)))
    
    res <- NULL
    if (!is.null(fit)){
      res <- list()
      res$stan <- fit
      
      res$formula <- formula
      
      res$y <- Y
      res$x <- X
      res$algorithm <- algorithm
      res$call <- call
      class(res) <- "multi_nb"
    }
  }
  
  if (algorithm == "sampling") 
    res <- sampling(sm, data=Dat, init=0, iter=iter, chains=chains)
  
  if (algorithm == "vb") 
    res <- vb(sm, data=Dat, init=0, iter=iter)
  
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units="min"), 3)
  if (verbose) 
    cat("\n Computational time:", minutes, "minutes \n")
  
  return(res)
}



