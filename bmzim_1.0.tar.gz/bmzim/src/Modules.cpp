#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4b_cauchy_mod) {


    class_<rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> >("model_b_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_b_cauchy_namespace::model_b_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4g_cauchy_mod) {


    class_<rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> >("model_g_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_g_cauchy_namespace::model_g_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4nb_cauchy_mod) {


    class_<rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> >("model_nb_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_nb_cauchy_namespace::model_nb_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4t_cauchy_mod) {


    class_<rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> >("model_t_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_t_cauchy_namespace::model_t_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zib_cauchy_mod) {


    class_<rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> >("model_zib_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zib_cauchy_namespace::model_zib_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zig_cauchy_mod) {


    class_<rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> >("model_zig_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zig_cauchy_namespace::model_zig_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zinb_cauchy_mod) {


    class_<rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> >("model_zinb_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zinb_cauchy_namespace::model_zinb_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zit_cauchy_mod) {


    class_<rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> >("model_zit_cauchy")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zit_cauchy_namespace::model_zit_cauchy, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
