#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4b_stan_mod) {


    class_<rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> >("model_b_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_b_stan_namespace::model_b_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4g_stan_mod) {


    class_<rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> >("model_g_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_g_stan_namespace::model_g_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4nb_stan_mod) {


    class_<rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> >("model_nb_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_nb_stan_namespace::model_nb_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4t_stan_mod) {


    class_<rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> >("model_t_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_t_stan_namespace::model_t_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zib_stan_mod) {


    class_<rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> >("model_zib_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zib_stan_namespace::model_zib_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zig_stan_mod) {


    class_<rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> >("model_zig_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zig_stan_namespace::model_zig_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zinb_stan_mod) {


    class_<rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> >("model_zinb_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zinb_stan_namespace::model_zinb_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
#include <Rcpp.h>
using namespace Rcpp ;
#include "include/models.hpp"

RCPP_MODULE(stan_fit4zit_stan_mod) {


    class_<rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> >("model_zit_stan")

    .constructor<SEXP,SEXP>()


    .method("call_sampler", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::call_sampler)
    .method("param_names", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::param_names)
    .method("param_names_oi", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::param_names_oi)
    .method("param_fnames_oi", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::param_fnames_oi)
    .method("param_dims", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::param_dims)
    .method("param_dims_oi", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::param_dims_oi)
    .method("update_param_oi", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::update_param_oi)
    .method("param_oi_tidx", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::param_oi_tidx)
    .method("grad_log_prob", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::grad_log_prob)
    .method("log_prob", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::log_prob)
    .method("unconstrain_pars", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::unconstrain_pars)
    .method("constrain_pars", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::constrain_pars)
    .method("num_pars_unconstrained", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::num_pars_unconstrained)
    .method("unconstrained_param_names", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::unconstrained_param_names)
    .method("constrained_param_names", &rstan::stan_fit<model_zit_stan_namespace::model_zit_stan, boost::random::ecuyer1988> ::constrained_param_names)
    ;
}
