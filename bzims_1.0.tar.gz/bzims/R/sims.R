

sims <- function(n = 1000, m.d = 100, m.z = 0, m.w = 0,
                 x.d, coef.d = 0, 
                 x.z, coef.z = 0, p.zero = 0,
                 x.w, coef.w = 0, theta = 2, df = 2)
{
  if (missing(x.d)) x.d <- simx(n = n, m = m.d, corr = 0.6)
  if (missing(x.z)){ 
    if (m.z > 0) x.z <- simx(n = n, m = m.z, corr = 0.5)
    else x.z <- array(0, c(n, 1)) 
  } 
  if (missing(x.w)){ 
    if (m.w > 0) x.w <- simx(n = n, m = m.w, corr = 0.5)
    else x.w <- array(0, c(n, 1)) 
  } 
  if (is.null(colnames(x.d))) 
    colnames(x.d) <- paste("xd", 1:NCOL(x.d), sep = "")
  if (is.null(colnames(x.z))) 
    colnames(x.z) <- paste("xz", 1:NCOL(x.z), sep = "") 
  if (is.null(colnames(x.w))) 
    colnames(x.w) <- paste("xw", 1:NCOL(x.w), sep = "") 
  
  mu <- runif(n, 0.1, 3.5)
  tn <- exp(mu)/exp(-7)    

  eta <- x.z %*% coef.z
  y.normal <- rnorm(n, -eta, 1.6)
  quantiles <- quantile(y.normal, p.zero)
  y.z <- as.numeric( factor(cut(y.normal, breaks = c(-Inf, quantiles, Inf))) ) - 1  

  mu.theta <- log(theta)
  theta <- sigma <- exp(mu.theta + x.w %*% coef.w)
  
  eta <- x.d %*% coef.d
  y.nb <- rnbinom(n, mu = exp(mu + eta), size = theta)
  y.normal <- rnorm(n, eta, sigma)
  y.t <- as.vector(eta + rt(n, df)*sigma)
  mu.beta <- exp(eta)/(1 + exp(eta))
  y.beta <- rbeta(n, mu.beta*theta, (1-mu.beta)*theta)
  
  y.nb <- ifelse(y.z == 0, 0, y.nb)
  y.normal <- ifelse(y.z == 0, 0, y.normal)
  y.t <- ifelse(y.z == 0, 0, y.t)
  y.beta <- ifelse(y.z == 0, 0, y.beta)
  
  list(x.d = x.d, x.z = x.z, x.w = x.w, T = tn, theta = theta, y.z = y.z, 
       y.nb = y.nb, y.normal = y.normal, y.t = y.t, y.beta = y.beta)
}

#*****************************************************************************************

simx <- function(n, m, corr = 0.6, method = c("svd", "chol", "eigen"))
{
  V <- array(corr, c(m, m))
  for (j in 1:m) V[j, j] <- 1
  method <- method[1]
  x <- rmvnorm(n = n, mean = rep(0, m), sigma = V, method = method)
  
  return(x)
}

rmvnorm <- function (n, mean = rep(0, nrow(sigma)), sigma = diag(length(mean)), 
                     method = c("svd", "eigen", "chol"), pre0.9_9994 = FALSE) 
{
  if (!isSymmetric(sigma, tol = sqrt(.Machine$double.eps), 
                   check.attributes = FALSE)) {
    stop("sigma must be a symmetric matrix")
  }
  if (length(mean) != nrow(sigma)) 
    stop("mean and sigma have non-conforming size")
  method <- match.arg(method)
  R <- if (method == "eigen") {
    ev <- eigen(sigma, symmetric = TRUE)
    if (!all(ev$values >= -sqrt(.Machine$double.eps) * abs(ev$values[1]))) {
      warning("sigma is numerically not positive definite")
    }
    t(ev$vectors %*% (t(ev$vectors) * sqrt(ev$values)))
  }
  else if (method == "svd") {
    s. <- svd(sigma)
    if (!all(s.$d >= -sqrt(.Machine$double.eps) * abs(s.$d[1]))) {
      warning("sigma is numerically not positive definite")
    }
    t(s.$v %*% (t(s.$u) * sqrt(s.$d)))
  }
  else if (method == "chol") {
    R <- chol(sigma, pivot = TRUE)
    R[, order(attr(R, "pivot"))]
  }
  retval <- matrix(rnorm(n * ncol(sigma)), nrow = n, byrow = !pre0.9_9994) %*% R
  retval <- sweep(retval, 2, mean, "+")
  nm <- names(mean)
  if (is.null(nm) && !is.null(colnames(sigma))) nm <- colnames(sigma)
  colnames(retval) <- nm
  if (n == 1) drop(retval)
  else retval
}

