

bm <- function (formula, data, subset, offset, family = c("nb", "gaussian", "beta", "t"), 
                algorithm = c("optimizing", "sampling", "vb"), init = 0,
                hessian = TRUE, s = 1, iter = 2000, chains = 3) 
{
  family <- family[1]
  algorithm <- algorithm[1]
  if (s==Inf) s <- 1e+05
  call <- match.call()
  if (missing(data)) data <- environment(formula)
  mf <- match.call(expand.dots = FALSE)
  m <- match(c("formula", "data", "subset", "na.action", "weights", "offset"), names(mf), 0)
  mf <- mf[c(1, m)]
  mf$drop.unused.levels <- TRUE
  mf[[1]] <- as.name("model.frame")
  mf <- eval(mf, parent.frame())
  mt <- attr(mf, "terms")
  X <- model.matrix(mt, mf)
  Y <- model.response(mf, "numeric")
  nobs <- length(Y)
  K <- NCOL(X)
  offset <- as.vector(model.offset(mf))
  if (!is.null(offset)) {
    if (length(offset) != NROW(Y)) 
      stop(gettextf("number of offsets is %d should equal %d (number of observations)", 
                    length(offset), NROW(Y)), domain = NA)
  }
  if (is.null(offset)) offset <- rep.int(0, nobs)
  X0 <- X
  if (colnames(X)[1]=="(Intercept)") X0 <- X[, -1, drop = FALSE]
  
#  J <- NCOL(X0)
#  if (length(s) < J) s <- c(s, rep(s[length(s)], J - length(s)) )
  
  res <- list()
  Dat <- list(n=nobs, K=NCOL(X0), x=X0, y=Y, offset=offset, s=s)
  if (family == "nb") sm <- stanmodels$nb_cauchy
  if (family == "gaussian") sm <- stanmodels$g_cauchy
  if (family == "beta") sm <- stanmodels$b_cauchy
  if (family == "t") sm <- stanmodels$t_cauchy
  
  if (algorithm == "optimizing") {
    fit <- optimizing(sm, data=Dat, init=init, hessian=hessian, iter=iter)
    
    res$stan <- fit
    coef <- fit$par[1:NCOL(X)]
    names(coef) <- colnames(X)
    res$coefficients <- coef
    eta <- mu <- offset + X%*%coef
    
    if (family=="nb") {
      res$theta <- fit$par[(K+1)]
      mu <- exp(eta)
      den <- dnbinom(Y, size=res$theta, mu=mu)
    }
    if (family=="beta") {
      res$theta <- fit$par[(K+1)]
      mu <- exp(eta)/(1 + exp(eta))
      den <- dbeta(Y, mu*res$theta, (1-mu)*res$theta)
    }
    if (family=="gaussian") {
      res$sigma <- fit$par[(K+1)]
      den <- dnorm(Y, mu, res$sigma)
    }
    if (family=="t") {
      res$sigma <- fit$par[(K+1)]
      res$df <- 1/fit$par[(K+2)]
      names(res$df) <- "df"
      den <- dt((Y-mu)/res$sigma, res$df)
    }  
    
    res$loglik <- sum(log(den))
    res$fitted.values <- mu
    res$linear.predictors <- eta
  }
  
  if (algorithm == "sampling") 
    res$stan <- sampling(sm, data=Dat, init=init, iter=iter, chains=chains)
  
  if (algorithm == "vb") 
    res$stan <- vb(sm, data=Dat, init=init, iter=iter)
  
  res$model <- mf
  res$y <- Y
  res$x <- X
  res$offset <- offset
  res$family <- family
  res$algorithm <- algorithm
  
  res$call <- call
  
  class(res) <- "bm"
  return(res)
}



