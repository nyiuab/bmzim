

bm <- function (formula, data, family = c("nb", "gaussian", "t", "beta"), 
                algorithm = c("optimizing", "sampling", "vb"), init = 0,
                hessian = TRUE, s_dist = 1, s_disp = 1, iter = 2000, chains = 3, 
                verbose = FALSE) 
{
  start.time <- Sys.time()
  
  call <- match.call()
  family <- family[1]
  algorithm <- algorithm[1]
  if (s_dist==Inf) s_dist <- 1e+05
  if (s_disp==Inf) s_disp <- 1e+05
  if (missing(data)) data <- environment(formula)
  
  two <- two.fm(formula = formula, data = data)
  Y <- two$Y
  X <- two$X
  Z <- two$Z
  offsetx <- two$offsetx
  offsetz <- two$offsetz
  
  nobs <- length(Y)
  kx <- NCOL(X) 
  kz <- NCOL(Z)
  X0 <- X
  if (colnames(X)[1]=="(Intercept)") X0 <- X[, -1, drop = FALSE]
  
  res <- list()
  Dat <- list(n=nobs, kx=NCOL(X0), kz=NCOL(Z), x=X0, z=Z, y=Y, offsetx=offsetx, offsetz=offsetz, s1=s_dist, s2=s_disp)
  
  if (family == "nb") sm <- stanmodels$nb_cauchy
  if (family == "gaussian") sm <- stanmodels$g_cauchy
  if (family == "t") sm <- stanmodels$t_cauchy
  if (family == "beta") sm <- stanmodels$b_cauchy
  
  if (algorithm == "optimizing") {
    fit <- optimizing(sm, data=Dat, init=init, hessian=hessian, iter=iter)
    
    res$stan <- fit
    coefx <- fit$par[1:kx]
    names(coefx) <- colnames(X)
    coefz <- fit$par[(kx+1):(kx+kz)]
    names(coefz) <- colnames(Z)
    res$coefficients <- list(dist = coefx, disp = coefz)
    dist.eta <- mu <- offsetx + X%*%coefx
    disp.eta <- offsetz + Z%*%coefz
    
    if (family=="nb") {
      res$theta <- exp(disp.eta)
      mu <- exp(dist.eta)
      den <- dnbinom(Y, size=res$theta, mu=mu)
    }
    if (family=="gaussian") {
      res$sigma <- exp(disp.eta)
      den <- dnorm(Y, mu, res$sigma)
    }
    if (family=="t") {
      res$sigma <- exp(disp.eta)
      res$df <- 1/fit$par[(kx+kz+1)]
      names(res$df) <- "df"
      den <- dt((Y-mu)/res$sigma, res$df)
    } 
    if (family=="beta") {
      res$theta <- exp(disp.eta)
      mu <- exp(dist.eta)/(1 + exp(dist.eta))
      den <- dbeta(Y, mu*res$theta, (1-mu)*res$theta)
    }
    
    res$loglik <- sum(log(den))
    res$fitted.values <- mu
    res$linear.predictors <- list(dist=dist.eta, disp=disp.eta)
    
    res$formula.dist <- two$fmc
    res$formula.disp <- two$fmz
    res$y <- Y
    res$x <- list(dist=X, disp=Z)
    res$offset <- list(dist=offsetx, disp=offsetz)
    res$family <- family
    res$algorithm <- algorithm
    res$call <- call
    class(res) <- "bm"
  }
  
  if (algorithm == "sampling") 
    res <- sampling(sm, data=Dat, init=init, iter=iter, chains=chains)
  
  if (algorithm == "vb") 
    res <- vb(sm, data=Dat, init=init, iter=iter)
  
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units="min"), 3)
  if (verbose) 
    cat("\n Computational time:", minutes, "minutes \n")
  
  return(res)
}



