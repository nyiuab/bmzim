
summary.optim <- function(object)
{
  if (object$algorithm != "optimizing") stop("this function only summarizes models fitted with optimizing")
  if (class(object) == "bzim") res <- summary.bzim(object)
  if (class(object) == "bm") res <- summary.bm(object)
  res
}



summary.bzim <- function(object) 
{
  coefs <- object$coefficients
  kx <- length(coefs[[1]])
  kz <- length(coefs[[2]])
  par <- c(coefs[[1]], coefs[[2]], object$theta, object$sigma, object$df) 
  dp <- c(1:kx) #(kx+kz+1):length(par))
  zp <- c((kx+1):(kx+kz))
  res <- list(dist=par[dp], zero=par[zp])
  hess <- object$stan$hessian
  if (!missing(hess)){
    if (NCOL(hess) > 1) vc <- -solve(hess + diag(rep(1e-03, NCOL(hess))))
    else vc <- -1/(hess + 1e-03)
    diag.vc <- diag(vc)
    s.err <- sqrt(diag.vc)
    tvalue <- par/s.err
    pvalue <- 2 * pnorm(-abs(tvalue))
    res[[1]] <- cbind(par[dp], s.err[dp], pvalue[dp])
    res[[2]] <- cbind(par[zp], s.err[zp], pvalue[zp])
    colnames(res[[1]]) <- colnames(res[[2]]) <- c("Estimate", "Std. Error", "pvalue")  
  }
  
  res
}

summary.bm <- function(object) 
{
  coefs <- object$coefficients
  par <- c(coefs, object$theta, object$sigma, object$df) 
  res <- coefs
  hess <- object$stan$hessian
  if (!missing(hess)){
    if (NCOL(hess) > 1) vc <- -solve(hess + diag(rep(1e-03, NCOL(hess))))
    else vc <- -1/(hess + 1e-03)
    diag.vc <- diag(vc)
    names(diag.vc) <- names(object$par)
    if (any(diag.vc <= 0)) warning("some variances are negative", call. = FALSE)
    s.err <- sqrt(diag.vc)
    tvalue <- par/s.err
    pvalue <- 2 * pnorm(-abs(tvalue))
    res <- cbind(par, s.err, pvalue)[1:length(coefs), , drop = FALSE]
    colnames(res) <- c("Estimate", "Std. Error", "pvalue")
  }
  
  res
}




