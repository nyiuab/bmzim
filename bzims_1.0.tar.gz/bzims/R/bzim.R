

bzim <- function (formula, data, family = c("zinb", "zig", "zit", "zib"), 
                  algorithm = c("optimizing", "sampling", "vb"), init = 0,
                  hessian = TRUE, s_dist = 1, s_zero = 1, s_disp = 1,
                  iter = 2000, chains = 3, verbose = FALSE) 
{
  start.time <- Sys.time()
  
  call <- match.call()
  family <- family[1]
  algorithm <- algorithm[1]
  if (s_dist==Inf) s_dist <- 1e+05
  if (s_zero==Inf) s_zero <- 1e+05
  if (s_disp==Inf) s_zero <- 1e+05
  if (missing(data)) data <- environment(formula)
  
  three <- three.fm(formula = formula, data = data)
  Y <- three$Y
  X <- three$X
  Z <- three$Z
  W <- three$W
  offsetx <- three$offsetx
  offsetz <- three$offsetz
  offsetw <- three$offsetw
  
  if (all(Y != 0)) stop("invalid dependent variable, all outcome values are not zero")
  nobs <- length(Y)
  kx <- NCOL(X) 
  kz <- NCOL(Z)
  kw <- NCOL(W)
  X0 <- X
  if (colnames(X)[1]=="(Intercept)") X0 <- X[, -1, drop = FALSE]
  
  res <- list()
  Dat <- list(n=nobs, kx=NCOL(X0), kz=NCOL(Z), kw=NCOL(W), x=X0, z=Z, w=W, y=Y, 
              offsetx=offsetx, offsetz=offsetz, offsetw=offsetw, 
              s1=s_dist, s2=s_zero, s3=s_disp)
  if (family == "zinb") sm <- stanmodels$zinb_cauchy
  if (family == "zig") sm <- stanmodels$zig_cauchy 
  if (family == "zit") sm <- stanmodels$zit_cauchy
  if (family == "zib") sm <- stanmodels$zig_cauchy
  
  if (algorithm == "optimizing") {
    fit <- optimizing(sm, data=Dat, init=init, hessian=hessian, iter=iter)
    
    res$stan <- fit
    coefx <- fit$par[1:kx]
    names(coefx) <- colnames(X)
    coefz <- fit$par[(kx+1):(kx+kz)]
    names(coefz) <- colnames(Z)
    coefw <- fit$par[(kx+kz+1):(kx+kz+kw)]
    names(coefw) <- colnames(W)
    res$coefficients <- list(dist=coefx, zero=coefz, disp=coefw)
    dist.eta <- mu <- offsetx + X%*%coefx
    zero.eta <- offsetz + Z%*%coefz
    disp.eta <- offsetw + W%*%coefw
    
    if (family=="zinb") {
      res$theta <- exp(disp.eta)
      mu <- exp(dist.eta)
      den <- dnbinom(Y, size=res$theta, mu=mu)
    }
    if (family == "zig") {
      res$sigma <- exp(disp.eta)
      den <- dnorm(Y, mu, res$sigma)
    }
    if (family == "zit") {
      res$sigma <- exp(disp.eta)
      res$df <- 1/fit$par[(kx+kz+kw+1)]
      names(res$df) <- "df"
      den <- dt((Y-mu)/res$sigma, res$df)  
    }
    if (family=="zib") {
      res$theta <- exp(disp.eta)
      mu <- exp(dist.eta)/(1 + exp(dist.eta))
      den <- dbeta(Y, mu*res$theta, (1-mu)*res$theta)
    }
    
    zero.prob <- exp(zero.eta)/(1 + exp(zero.eta))
    zp <- 1/(1 + exp(-zero.eta) * den )
    zp <- ifelse(Y != 0, 0, zp)
    loglik0 <- log(zero.prob + (1 - zero.prob) * den)
    loglik1 <- log((1 - zero.prob) * den)
    res$loglik <- sum(loglik0[Y == 0]) + sum(loglik1[Y != 0])
    res$zero.prob <- as.vector(zero.prob)
    fit$zero.indicator <- zp
    res$fitted.values <- (1 - zero.prob) * mu
    res$linear.predictors <- list(dist=dist.eta, zero=zero.eta, disp=disp.eta)
  }
  
  if (algorithm == "sampling") 
    res$stan <- sampling(sm, data=Dat, init=init, iter=iter, chains=chains)
  
  if (algorithm == "vb") 
    res$stan <- vb(sm, data=Dat, init=init, iter=iter)
  
  res$formula.dist <- three$fmc
  res$formula.zero <- three$fmz
  res$formula.disp <- three$fmw
  res$y <- Y
  res$x <- list(dist=X, zero=Z, disp=W)
  res$offset <- list(dist=offsetx, zero=offsetz, disp=offsetw)
  res$family <- family
  res$algorithm <- algorithm
  res$call <- call
  class(res) <- "bzim"
  
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units = "min"), 3)
  if (verbose) 
    cat("\n Computational time:", minutes, "minutes \n")
  
  return(res)
}



