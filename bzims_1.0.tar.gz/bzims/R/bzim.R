

bzim <- function (formula, data, family = c("zinb", "zig", "zit", "zib"), 
                  algorithm = c("optimizing", "sampling", "vb"), init = 0,
                  hessian = TRUE, s_dist = 1, s_zero = 1, iter = 2000, chains = 3, 
                  verbose = FALSE, ...) 
{
  start.time <- Sys.time()
  
  family <- family[1]
  algorithm <- algorithm[1]
  if (s_dist==Inf) s_dist <- 1e+05
  if (s_zero==Inf) s_zero <- 1e+05
  call <- match.call()
  if (missing(data)) data <- environment(formula)
  mf <- match.call(expand.dots = FALSE)
  m <- match(c("formula", "data", "subset", "na.action", "weights", "offset"), names(mf), 0)
  mf <- mf[c(1, m)]
  mf$drop.unused.levels <- TRUE
  if (length(formula[[3]]) > 1 && identical(formula[[3]][[1]], as.name("|"))) {
    ff <- formula
    formula[[3]][1] <- call("+")
    mf$formula <- formula
    ffc <- . ~ .
    ffz <- ~.
    ffc[[2]] <- ff[[2]]
    ffc[[3]] <- ff[[3]][[2]]
    ffz[[3]] <- ff[[3]][[3]]
    ffz[[2]] <- NULL
  }
  else {
    ffz <- ffc <- ff <- formula
    ffz[[2]] <- NULL
  }
  if (inherits(try(terms(ffz), silent = TRUE), "try-error")) {
    ffz <- eval(parse(text = sprintf(paste("%s -", deparse(ffc[[2]])), deparse(ffz))))
  }
  mf[[1]] <- as.name("model.frame")
  mf <- eval(mf, parent.frame())
  mt <- attr(mf, "terms")
  mtX <- terms(ffc, data = data)
  X <- model.matrix(mtX, mf)
  mtZ <- terms(ffz, data = data)
  mtZ <- terms(update(mtZ, ~.), data = data)
  Z <- model.matrix(mtZ, mf)
  Y <- model.response(mf, "numeric")
  if (all(Y != 0)) stop("invalid dependent variable, all outcome values are not zero")
  nobs <- length(Y)
  kx <- NCOL(X) 
  kz <- NCOL(Z)
  offsetx <- model_offset_2(mf, terms = mtX, offset = TRUE)
  if (is.null(offsetx)) offsetx <- 0
  if (length(offsetx) == 1) offsetx <- rep.int(offsetx, nobs)
  offsetx <- as.vector(offsetx)
  offsetz <- model_offset_2(mf, terms = mtZ, offset = FALSE)
  if (is.null(offsetz)) offsetz <- 0
  if (length(offsetz) == 1) offsetz <- rep.int(offsetz, nobs)
  offsetz <- as.vector(offsetz)
  X0 <- X
  if (colnames(X)[1]=="(Intercept)") X0 <- X[, -1, drop = FALSE]
  
#  J <- NCOL(X0)
#  if (length(s_dist) < J) s_dist <- c(s_dist, rep(s_dist[length(s_dist)], J - length(s_dist)) )
  
  res <- list()
  Dat <- list(n=nobs, kx=NCOL(X0), kz=NCOL(Z), x=X0, z=Z, y=Y, offsetx=offsetx, offsetz=offsetz, s1=s_dist, s2=s_zero)
  if (family == "zinb") sm <- stanmodels$zinb_cauchy
  if (family == "zig") sm <- stanmodels$zig_cauchy 
  if (family == "zib") sm <- stanmodels$zig_cauchy  
  if (family == "zit") sm <- stanmodels$zit_cauchy 
  
  if (algorithm == "optimizing") {
    fit <- optimizing(sm, data=Dat, init=init, hessian=hessian, iter=iter)
    
    res$stan <- fit
    coefx <- fit$par[1:kx]
    names(coefx) <- colnames(X)
    coefz <- fit$par[(kx+1):(kx+kz)]
    names(coefz) <- colnames(Z)
    res$coefficients <- list(dist = coefx, zero = coefz)
    dist.eta <- mu <- offsetx + X%*%coefx
    
    if (family=="zinb") {
      res$theta <- fit$par[(kx+kz+1)]
      mu <- exp(dist.eta)
      den <- dnbinom(Y, size=res$theta, mu=mu)
    }
    if (family=="zib") {
      res$theta <- fit$par[(kx+kz+1)]
      mu <- exp(dist.eta)/(1 + exp(dist.eta))
      den <- dbeta(Y, mu*res$theta, (1-mu)*res$theta)
    }
    if (family == "zig") {
      res$sigma <- fit$par[(kx+kz+1)]
      den <- dnorm(Y, mu, res$sigma)
    }
    if (family == "zit") {
      res$sigma <- fit$par[(kx+kz+1)]
      res$df <- 1/fit$par[(kx+kz+2)]
      names(res$df) <- "df"
      den <- dt((Y-mu)/res$sigma, res$df)  
    }
    
    zero.eta <- offsetz + Z%*%coefz
    zero.prob <- exp(zero.eta)/(1 + exp(zero.eta))
    zp <- 1/(1 + exp(-zero.eta) * den )
    zp <- ifelse(Y != 0, 0, zp)
    loglik0 <- log(zero.prob + (1 - zero.prob) * den)
    loglik1 <- log((1 - zero.prob) * den)
    res$loglik <- sum(loglik0[Y == 0]) + sum(loglik1[Y != 0])
    res$zero.prob <- as.vector(zero.prob)
    fit$zero.indicator <- zp
    res$fitted.values <- (1 - zero.prob) * mu
    res$linear.predictors <- list(dist = dist.eta, zero = zero.eta)
  }
  
  if (algorithm == "sampling") 
    res$stan <- sampling(sm, data=Dat, init=init, iter=iter, chains=chains)
  
  if (algorithm == "vb") 
    res$stan <- vb(sm, data=Dat, init=init, iter=iter)
  
  res$model <- mf
  res$y <- Y
  res$x <- list(dist = X, zero = Z)
  res$offset <- list(dist = offsetx, zero = offsetz)
  res$family <- family
  res$algorithm <- algorithm
  res$call <- call
  class(res) <- "bzim"
  
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units = "min"), 3)
  if (verbose) 
    cat("\n Computational time:", minutes, "minutes \n")
  
  return(res)
}



