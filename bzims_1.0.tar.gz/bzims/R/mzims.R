
mzims <- function(y, formula, data, family = "nb", s_dist = 1, s_zero = 1,
                  min.p = 0, verbose = TRUE)
{
  start.time <- Sys.time()
  
  call <- match.call()
  family <- family[1]
  y <- as.matrix(y)
  if (is.null(rownames(y))) rownames(y) <- paste("v", 1:nrow(y), sep = "")
  if (is.null(colnames(y))) colnames(y) <- paste("y", 1:ncol(y), sep = "")
  if (ncol(y) > 1 & min.p > 0){
    nonzero.p <- apply(y, 2, function(z) {length(z[z != 0])/length(z)} )
    nonzero.p <- sort(nonzero.p, decreasing = T)
    sub <- names(nonzero.p[nonzero.p > min.p])
    if (length(sub) == 0) stop("min.p is too large: no response") 
    else y <- y[, sub, drop = FALSE]
  }
  if (missing(data)) data <- NULL
  
  fm <- y.one ~ .
  fm[[3]] <- formula[[2]]
  fit <- list()
  for (j in 1:ncol(y)){
    y.one <- y[, j]
    data <- data.frame(cbind(y.one, data))
    tryCatch( {
      if (family %in% c("nb", "gaussian", "beta", "t"))
        fit[[j]] <- bm(formula = fm, data = data, family = family, s = s_dist) 
      if (family %in% c("zinb", "zig", "zib", "zit"))
        fit[[j]] <- bzim(formula = fm, data = data, family = family, s_dist = s_dist, s_zero = s_zero) 
      
      pre <- rep("\b", ncol(y))
      cat(pre, "\n", j, "/", ncol(y), sep="")
    }, error = function(e) {cat("\n", "y", j, " error: ", conditionMessage(e), sep="")} )
  } 
  names(fit) <- colnames(y)
  
  coefs <- coefs.mzims(fit)
  
  res <- list(coefs = coefs, call = call)
  
  class(res) <- c("mzims", family)
  stop.time <- Sys.time()
  minutes <- round(difftime(stop.time, start.time, units = "min"), 3)
  if (verbose) 
    cat("\n Computational time:", minutes, "minutes \n")
  
  res
}


coefs.mzims <- function(fit)
{
  fit <- fit[-which(sapply(fit, is.null))]
  
  if (fit[[1]]$family %in% c("nb", "gaussian", "beta", "t")){
    res <- list()
    Estimate <- Std.Error <- pvalue <- nam <- NULL
    for (j in 1:length(fit)){
      fix <- summary.optim(fit[[j]]) 
      nam <- c(nam, names(fit)[j])
      Estimate <- cbind(Estimate, fix[, 1, drop = FALSE])
      Std.Error <- cbind(Std.Error, fix[, 2, drop = FALSE])
      pvalue <- cbind(pvalue, fix[, 3, drop = FALSE])
    }
    colnames(Estimate) <- colnames(Std.Error) <- colnames(pvalue) <- nam
    Estimate <- round(Estimate, 3)
    Std.Error <- round(Std.Error, 3)
    pvalue <- signif(pvalue, 2)
    res$dist <- list(Estimate = Estimate, Std.Error = Std.Error, pvalue = pvalue)
    res$dist.r <- colnames(res$dist[[1]])
    res$dist.v <- rownames(res$dist[[1]])
  }
  
  if (fit[[1]]$family %in% c("zinb", "zig", "zib", "zit")){
    res <- list()
    
    Estimate <- Std.Error <- pvalue <- nam <- NULL
    for (j in 1:length(fit)){
      fix <- summary.optim(fit[[j]])$dist 
      nam <- c(nam, names(fit)[j])
      Estimate <- cbind(Estimate, fix[, 1, drop = FALSE])
      Std.Error <- cbind(Std.Error, fix[, 2, drop = FALSE])
      pvalue <- cbind(pvalue, fix[, 3, drop = FALSE])
    }
    colnames(Estimate) <- colnames(Std.Error) <- colnames(pvalue) <- nam
    Estimate <- round(Estimate, 3)
    Std.Error <- round(Std.Error, 3)
    pvalue <- signif(pvalue, 2)
    res$dist <- list(Estimate = Estimate, Std.Error = Std.Error, pvalue = pvalue)
    res$dist.r <- colnames(res$dist[[1]])
    res$dist.v <- rownames(res$dist[[1]])
  
    Estimate <- Std.Error <- pvalue <- nam <- NULL
    for (j in 1:length(fit)){
      fix <- summary.optim(fit[[j]])$zero 
      nam <- c(nam, names(fit)[j])
      Estimate <- cbind(Estimate, fix[, 1, drop = FALSE])
      Std.Error <- cbind(Std.Error, fix[, 2, drop = FALSE])
      pvalue <- cbind(pvalue, fix[, 3, drop = FALSE])
    }
    colnames(Estimate) <- colnames(Std.Error) <- colnames(pvalue) <- nam
    Estimate <- round(Estimate, 3)
    Std.Error <- round(Std.Error, 3)
    pvalue <- signif(pvalue, 2)
    res$zero <- list(Estimate = Estimate, Std.Error = Std.Error, pvalue = pvalue)
    res$zero.r <- colnames(res$zero[[1]])
    res$zero.v <- rownames(res$zero[[1]])
    
  }
  
  res
}


