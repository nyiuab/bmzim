
get.coefs <- function(object, part = c("dist", "zero"), vr.name, sort.p = FALSE)
{
  part <- part[1]
  if (class(object)[1] != "mzims") 
    stop("only for object from 'mzims'")  
  if (!(class(object)[2] %in% c("zinb", "zig", "zib", "zit")) & part=="zero")
    stop("no zero-inflation part")
  object <- object$coefs
  
  if (part=="dist"){
    if (!vr.name %in% c(object$dist.r, object$dist.v)) stop("wrong name given")
    if (vr.name %in% object$dist.r)
      res <- cbind(object$dist$Estimate[, vr.name, drop=F],  
                   object$dist$Std.Error[, vr.name, drop=F],
                   object$dist$pvalue[, vr.name, drop=F] )
    if (vr.name %in% object$dist.v)
      res <- cbind(t(object$dist$Estimate[vr.name, , drop=F]),  
                   t(object$dist$Std.Error[vr.name, , drop=F]),
                   t(object$dist$pvalue[vr.name, , drop=F]) )
  }
  
  if (part=="zero"){
    if (!vr.name %in% c(object$zero.r, object$zero.v)) stop("wrong name given")
    if (vr.name %in% object$zero.r)
      res <- cbind(object$zero$Estimate[, vr.name, drop=F],  
                   object$zero$Std.Error[, vr.name, drop=F],
                   object$zero$pvalue[, vr.name, drop=F] )
    if (vr.name %in% object$zero.v)
      res <- cbind(t(object$zero$Estimate[vr.name, , drop=F]),  
                   t(object$zero$Std.Error[vr.name, , drop=F]),
                   t(object$zero$pvalue[vr.name, , drop=F]) )
  }
  
  res <- res[rownames(res)!="(Intercept)", , drop=FALSE]
  colnames(res) <- c("Estimate", "Std.Error", "pvalue")
  if (sort.p) res <- res[names(sort(res[, "pvalue"])), ]
  
  res
}
