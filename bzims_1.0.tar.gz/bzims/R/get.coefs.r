

get.coefs <- function(object, part=c("dist", "zero", "disp"), vr.name, sort.p=FALSE)
{
  part <- part[1]
  if (class(object)[1] != "mzims") 
    stop("only for object from 'mzims'")  
  if (!(class(object)[2] %in% c("zinb", "zig", "zib", "zit")) & part=="zero")
    stop("no zero-inflation part")
  fit <- object$fit
  res <- object$responses
  var <- object$variables
  if (!vr.name %in% c(res, unlist(var))) stop("wrong name given")
  if (vr.name %in% res){ 
    out <- lapply(fit, summary)[[vr.name]][[part]]
  }
  else{
    out <- sapply(summary(object)[[part]], function(x){x[vr.name, ]} )
  }
  out <- out[rownames(out)!="(Intercept)", ]
  if (sort.p) out <- out[names(sort(out[, "pvalue"])), ]
  
  out
}
    
  
